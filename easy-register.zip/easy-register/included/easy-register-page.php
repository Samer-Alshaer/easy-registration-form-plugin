<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Easy_Register_Form')) {
    class Easy_Register_Form
    {
        public function easy_register_form_shortcode()
        {
            add_shortcode('easy_register_en', [$this, 'easy_register_display_shortcode_en']);
            add_shortcode('easy_register_ar', [$this, 'easy_register_display_shortcode_ar']);
        }

        public function easy_register_display_shortcode_en($atts = [], $content = '', $tag = '')
        {
            ob_start();
            include(plugin_dir_path(__FILE__) . '/../easy-templates/easy-register-form.php');
            $result1 =  ob_get_clean();
            return $result1;
        }
        public function easy_register_display_shortcode_ar($atts = [], $content = '', $tag = '')
        {
            ob_start();
            include(plugin_dir_path(__FILE__) . '/../easy-templates/easy-register-form_ar.php');
            $result2 =  ob_get_clean();
            return $result2;
        }

        public function easy_register_form_register()
        {
            session_start();
            if (username_exists(sanitize_text_field($_POST['easy_user_name']))) {
                $_SESSION['easy_register_errors']['easy_user_name'] = "User Name Exists";
                $errors = true;
            }
            if (email_exists(sanitize_text_field($_POST['easy_email']))) {
                $_SESSION['easy_register_errors']['easy_email'] = "Email Exists";
                $errors = true;
            }
            if ($errors) {
                wp_redirect($_SERVER['HTTP_REFERER']);
                exit;
            }
            $result = wp_insert_user([
                'user_pass'  =>   sanitize_text_field($_POST['easy_password']),
                'user_login' =>   sanitize_text_field($_POST['easy_user_name']),
                'user_email' =>   sanitize_text_field($_POST['easy_email']),
                'first_name' =>   sanitize_text_field($_POST['easy_user_name'])
            ]);
            if ($result instanceof WP_Error) {
                $_SESSION['easy-register-errors'] =  $result->get_error_messages();
                wp_redirect($_SERVER['HTTP_REFERER']);
                exit;
            }
            wp_redirect(get_site_url(null, '/wp-admin'));
            exit;
            session_destroy();
        }
    }
}
