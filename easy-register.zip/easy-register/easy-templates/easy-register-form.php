<?php
session_start();
if (isset($_SESSION['easy_register_errors']) && !empty($_SESSION['easy_register_errors'])) {
?>
    <div class="alert-msg">
        <ul>
        <?php
        foreach ($_SESSION['easy_register_errors'] as  $msg) {
            ?>
            <li>
                <?php
                    esc_html_e($msg);
                ?>.  
            </li>     
    <?php
                }
                unset($_SESSION['easy_register_errors']);
            }
session_destroy();
    ?>
        </ul>
    </div>

    <form class="easy-form" method="POST" action="<?php echo esc_url(admin_url('admin-post.php'))  ?>">
        <input type="hidden" name="action" value="easy_register_form">
        <input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('easy_register_form')) ?>">
        <div class="easy-form-group">
            <label for="user_name">User Name</label>
            <input type="text" name="easy_user_name" required class="easy_user_name" id="user_name" placeholder="Enter Username">
        </div>
        <div class="easy-form-group">
            <label for="email">Email Address</label>
            <input type="email" name="easy_email" class="esay_email" id="email" placeholder="Enter email" required>
        </div>
        <div class="easy-form-group">
            <label for="password">Password</label>
            <input type="password" name="easy_password" class="esay_password" id="password" placeholder="Password" required>
        </div>
        <button type="submit" class="easy_btn">Register</button>
    </form>