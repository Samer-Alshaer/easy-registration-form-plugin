=== Easy Registration Form ===
Contributors: Samer Alshaer
Plugin Name: Easy Registration Form
Tags: register,easyRegister,subscribe,membership
Requires at least: 5.1
Tested up to: 5.9.1
Requires PHP : 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy Registration Form is a User Registration plugin.
=== Description ===

Easy Registration Form is a User Registration plugin to it allows users of your site to easily register with it.

Features include:
* It can be controlled by admin
* It can be controlled through the settings attached to this plugin
* Built-in WordPress locale codes
* Easy to integrate via (shortcode)
* 100% responsive
* Beautiful coded
* Easy to use
* Arabic and English Forms

= Installing manually: =

1. Unzip all files to the `wp-content/plugins/easy-register` directory
2. Log into WordPress admin and activate the 'Easy Registration Form' plugin through the 'Plugins' menu
3. Go to *Easy Registration Form > Home* in the left-hand menu to start it

=== Changelog ===
* 1.0 *
* Avery basic version added for Easy Registration Form system