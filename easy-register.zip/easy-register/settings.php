<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Easy_Register_Form_Settings')) {
    class Easy_Register_Form_Settings
    {

        public function __construct()
        {
            add_action('admin_menu', array($this, 'Easy_Register_Form_Settings_pageA'));
            add_action('admin_menu', array($this, 'Easy_Register_Form_Settings_pageB'));
        }

        public function Easy_Register_Form_Settings_pageA()
        {
            add_options_page(__('Easy Registration Form'), __('Easy Registration Form'), 'manage_options', 'Easy-Registration-Form', 'Easy_Register_Form_Settings_page');
        }

        public function Easy_Register_Form_Settings_pageB()
        {
            add_menu_page(__('Easy Registration Form'), __('Easy Registration Form'), 'manage_options', __('Easy-Registrations-Form'), 'Easy_Register_Form_Settings_page', 'dashicons-smiley');
        }
    }
    new Easy_Register_Form_Settings();
}

if (!function_exists('Easy_Register_Form_Settings_page')) {
    function Easy_Register_Form_Settings_page()
    {
?>
        <div class="easy_settings_cont">
            <h1><?php _e("Easy Registration Form ") ?></h1>
            <h3><?php _e("Easy Registration Form is a user registration plugin to it allows users of your site to easily register with it.") ?></h3>
            <h3 class="use"><?php _e("How To Use:") ?></h3>
            <h4><?php _e("All you have to do is put this shortcode on any page you want, and after putting it the form will appear automatically.") ?></h4>

            <div>
                <h3><?php _e("English Form:") ?></h3>
                <input tybe="text" disabled id="p1" value="<?php _e("[easy_register_en]") ?>"></input>
                <span class="tooltiptext1" id="myTooltip1"></span>
                <button onclick="easy_register_copy1()"><?php _e("Copy") ?></button>
            </div>

            <div style="margin-top:10px">
                <h3><?php _e("Arabic Form:") ?></h3>
                <input tybe="text" disabled id="p2" value="<?php _e("[easy_register_ar]") ?>"></input>
                <span class="tooltiptext2" id="myTooltip2"></span>
                <button onclick="easy_register_copy2()"><?php _e("Copy") ?></button>
            </div>
        </div>

        <style>
            .easy_settings_cont {
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                position: relative;
            }

            .easy_settings_cont h1 {
                color: #93003c;
            }

            .easy_settings_cont .use {
                color: #2271b1;
            }

            .easy_settings_cont input {
                color: #93003c;
                padding: 10px;
                width: 180px;
                font-size: 17px;
                border: none;
                background-color: #fff;
            }

            .easy_settings_cont button {
                color: #93003c;
                padding: 10px;
                cursor: pointer;
                font-size: 15px;
                border: 1px solid #93003c;
                background-color: #fff;

            }

            .easy_settings_cont button:hover {
                color: #fff;
                padding: 10px;
                cursor: pointer;
                font-size: 15px;
                border: 1px solid #93003c;
                background-color: #93003c;
                transition: .3s ease-in;
            }

            .tooltiptext1 {
                position: absolute;
                bottom: 45%;
                color: #93003c;
                padding: 5px;
            }

            .tooltiptext2 {
                position: absolute;
                bottom: 15%;
                color: #93003c;
                padding: 5px;
            }
        </style>

        <script>
            function easy_register_copy1() {
                var copyText1 = document.getElementById("p1");
                copyText1.select();
                copyText1.setSelectionRange(0, 99999);
                navigator.clipboard.writeText(copyText1.value);

                var tooltip1 = document.getElementById("myTooltip1");
                tooltip1.innerHTML = "Copied!"
            }

            function easy_register_copy2() {
                var copyText2 = document.getElementById("p2");
                copyText2.select();
                copyText2.setSelectionRange(0, 99999);
                navigator.clipboard.writeText(copyText2.value);
                var tooltip2 = document.getElementById("myTooltip2");
                tooltip2.innerHTML = "Copied!"
            }
        </script>
<?php
    }
}

?>