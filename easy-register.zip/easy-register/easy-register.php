<?php

/**
 * Plugin Name: Easy Registration Form
 * Description: Easy Registration Form is a User Registration plugin to it allows users of your site to easily register with it.
 * Version: 1.0
 * Author: Samer Alshaer
 * Plugin URI: https://wordpress.org/plugins/easy-registration-form/
 * Author URI: https://www.facebook.com/SamerAlshaer2020
 **/
if (!defined('ABSPATH')) {
    exit;
}

require_once('settings.php');

if (!function_exists('easy_register_scripts_Files')) {
    function easy_register_scripts_Files()
    {
        wp_enqueue_style('easy_register_style', plugin_dir_url(__FILE__) . '/easy-templates/css/style.css');
    }
}

add_action('wp_enqueue_scripts', 'easy_register_scripts_Files');

include(plugin_dir_path(__FILE__) . '/included/easy-register-page.php');
$r = new Easy_Register_Form();

add_action('init', [$r, 'easy_register_form_shortcode']);
add_action('admin_post_nopriv_easy_register_form', [$r, 'easy_register_form_register']);
